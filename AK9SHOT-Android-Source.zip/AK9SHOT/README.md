# AK9SHOT Android starter project

Yellow/black Jetpack Compose starter UI for an Android video/photo editor.

## Open and build
1. Install Android Studio (Hedgehog or newer) with Android SDK 35.
2. Open this folder (`AK9SHOT`) in Android Studio.
3. Allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).

Package: `com.ak9shot.editor`  
Minimum Android: 7.0 (API 24)  
Version: 0.1.0

## Current prototype features
- Yellow/black AK9SHOT home screen
- New Project media picker (video)
- Photo media picker entry point
- Quick-tool selection UI
- Projects/AI/Profile navigation shell

## Important
This is a starter UI prototype, not a finished editor. Actual video decoding, timeline editing, transitions, audio mixing, AI services, export/rendering, subscriptions, privacy policy, and testing are not implemented yet. Add these in staged development and test on real devices before release.

## Build APK from a phone (cloud build)
1. Sign in to GitHub in your phone browser and create a new **private** repository named `AK9SHOT`.
2. Upload the contents of this project folder to the repository (keep the `.github/workflows/android-apk.yml` file and its folders).
3. Open the repository's **Actions** tab and allow GitHub Actions if prompted.
4. Select **Build AK9SHOT APK** and tap **Run workflow** (or push to `main`).
5. When the run finishes, open it and download the `AK9SHOT-debug-apk` artifact. Extract it to get `app-debug.apk`.
6. Open the APK on your Android phone and allow installation from that source if Android asks.

This workflow builds a debug/test APK. It is not a Play Store release build. Keep the repository private if you do not want to publish your source code.
