package com.ak9shot.editor

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Yellow = Color(0xFFFFD400)
private val Black = Color(0xFF080808)
private val Panel = Color(0xFF171717)
private val Muted = Color(0xFF9A9A9A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AK9ShotApp() }
    }
}

@Composable
fun AK9ShotApp() {
    var selectedVideo by remember { mutableStateOf<Uri?>(null) }
    var selectedName by remember { mutableStateOf("कोई वीडियो चुना नहीं गया") }
    var activeTool by remember { mutableStateOf("Trim") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        selectedVideo = uri
        selectedName = if (uri != null) uri.lastPathSegment ?: "वीडियो चुना गया" else "कोई वीडियो चुना नहीं गया"
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Yellow, background = Black, surface = Panel)) {
        Scaffold(containerColor = Black, bottomBar = { BottomBar() }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).background(Black).padding(horizontal = 18.dp)) {
                Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).background(Yellow, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                        Text("AK", color = Black, fontWeight = FontWeight.Black, fontSize = 17.sp)
                    }
                    Spacer(Modifier.width(11.dp))
                    Column(Modifier.weight(1f)) {
                        Text("AK9SHOT", color = Yellow, fontWeight = FontWeight.Black, fontSize = 23.sp, letterSpacing = 1.sp)
                        Text("VIDEO • PHOTO • AI STUDIO", color = Muted, fontSize = 9.sp, letterSpacing = 1.4.sp)
                    }
                    Icon(Icons.Default.WorkspacePremium, null, tint = Yellow, modifier = Modifier.size(27.dp))
                }

                Text("आपका क्रिएटिव स्टूडियो", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                Text("वीडियो को अगले स्तर पर ले जाएँ।", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 5.dp, bottom = 18.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    ActionCard("New Project", "वीडियो एडिट करें", Icons.Default.Movie, Modifier.weight(1f)) { picker.launch("video/*") }
                    ActionCard("AI Studio", "स्मार्ट टूल्स", Icons.Default.AutoAwesome, Modifier.weight(1f)) { activeTool = "AI Studio" }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    ActionCard("Photo Edit", "फोटो बनाएँ", Icons.Default.Photo, Modifier.weight(1f)) { picker.launch("image/*") }
                    ActionCard("Collage", "फोटो मिलाएँ", Icons.Default.GridView, Modifier.weight(1f)) { activeTool = "Collage" }
                }

                Spacer(Modifier.height(22.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("EDITOR WORKSPACE", color = Yellow, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
                    Spacer(Modifier.weight(1f))
                    Text("BETA", color = Black, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.background(Yellow, RoundedCornerShape(5.dp)).padding(horizontal = 7.dp, vertical = 3.dp))
                }
                Spacer(Modifier.height(10.dp))
                Box(Modifier.fillMaxWidth().height(150.dp).background(Panel, RoundedCornerShape(16.dp)).border(1.dp, Color(0xFF303030), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(if (selectedVideo == null) Icons.Default.VideoLibrary else Icons.Default.CheckCircle, null, tint = Yellow, modifier = Modifier.size(35.dp))
                        Spacer(Modifier.height(8.dp))
                        Text(if (selectedVideo == null) "अपना मीडिया चुनें" else "मीडिया चुना गया", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text(selectedName, color = Muted, fontSize = 11.sp, maxLines = 1)
                        Spacer(Modifier.height(10.dp))
                        Text("IMPORT MEDIA", color = Black, fontWeight = FontWeight.Bold, fontSize = 10.sp, modifier = Modifier.background(Yellow, RoundedCornerShape(8.dp)).clickable { picker.launch("video/*") }.padding(horizontal = 15.dp, vertical = 8.dp))
                    }
                }

                Spacer(Modifier.height(18.dp))
                Text("QUICK TOOLS", color = Yellow, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    listOf("Trim", "Music", "Text", "Effects", "Filters", "Layers", "Speed", "AI Studio").forEach { tool ->
                        val active = activeTool == tool
                        Text(tool, color = if (active) Black else Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.background(if (active) Yellow else Panel, RoundedCornerShape(9.dp)).clickable { activeTool = tool }.padding(horizontal = 14.dp, vertical = 11.dp))
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("चुना गया टूल: $activeTool", color = Muted, fontSize = 11.sp)
                Spacer(Modifier.height(10.dp))
                Text("नोट: यह शुरुआती UI प्रोटोटाइप है। असली कटिंग, इफेक्ट रेंडरिंग और 4K एक्सपोर्ट अगले डेवलपमेंट चरणों में जोड़े जाएँगे।", color = Muted, fontSize = 10.sp, lineHeight = 15.sp)
            }
        }
    }
}

@Composable
private fun ActionCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.height(100.dp).background(Panel, RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(13.dp), verticalArrangement = Arrangement.SpaceBetween) {
        Icon(icon, null, tint = Yellow, modifier = Modifier.size(23.dp))
        Column {
            Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun BottomBar() {
    NavigationBar(containerColor = Color(0xFF111111), contentColor = Yellow) {
        NavigationBarItem(selected = true, onClick = {}, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
        NavigationBarItem(selected = false, onClick = {}, icon = { Icon(Icons.Default.Folder, null) }, label = { Text("Projects") })
        NavigationBarItem(selected = false, onClick = {}, icon = { Icon(Icons.Default.AutoAwesome, null) }, label = { Text("AI Tools") })
        NavigationBarItem(selected = false, onClick = {}, icon = { Icon(Icons.Default.Person, null) }, label = { Text("Profile") })
    }
}
